# About

KantOS theme for SpruceOS, based on the work of the KantOS theme for OnionOS by [antonlabz](https://github.com/antonlabz/KantOS).

# Installation

Extract the contents of the zip file into the Themes directory on your sd card that has SpruceOS installed on it.

# Screenshot

![previews](preview.gif)