
Pokemon artwork by Ken Sugimori

Icons: IBM's Carbon Design System
https://carbondesignsystem.com/elements/icons/library/ 

Game Icons: Pineapple.Graphics 
https://archive.org/details/@pineapple_graphics

The theme started off as a mod of ‘Cosy by KyleBing’ so there may be some leftover assets. 

Some assets have also been recoloured from ‘Spruce by tenlevels’

My personal display settings
Lum 6
Hue 9
Sat 16 
Con 10


