# `Glamoruce` *by* `metallic77`

Theme for spruce modded stock os


## Credits

** Font:** ubuntu italic

**Icons:** various sources on internet, some icons borrowed
from Cosy to speed up dev. Expect amendments.

**Console icons:** various sources on internet 

Created with GIMP